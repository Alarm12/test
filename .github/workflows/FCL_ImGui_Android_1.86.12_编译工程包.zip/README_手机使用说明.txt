FCL ImGui 1.86.12 Android ARM64 修复研究：手机云端构建包
========================================================
状态：实验性源码构建方案；尚未生成或验证可在你的 FCL 上运行的 Android .so。
当前环境无法下载完整 imgui-java 上游源码及 Android NDK，无法替你完成云端构建。
因此这个包提供的是可复现的 GitHub Actions 编译配置，不是假装已修好的原生库。

1. 研究结论
- 你上传的 HELoutreImGuiPart-1.0.jar 和 HueihueaEngine-1.0-srg_20261004.jar
  均带有 imgui.java.version=1.86.12，只附带 Windows imgui-java64.dll。
- 你最新日志：
  no imgui-java64 in java.library.path
  at imgui.ImGui.<clinit>(ImGui.java:59)
  at loutre.imgui.ImGuiBootstrap.installAssertCallbackEarly(...)
- imgui.ImGui 的现有 Java 字节码支持从类路径提取
  io/imgui/java/native-bin/libimgui-java64.so；
  提取位置在 FCL 的 Java 私有缓存，无需手机 root。
- 上游提供 v1.86.12 JNI 源码，但没有找到已证实兼容的 Android ARM64 成品。
- 你现有 Windows DLL 的 Java_imgui_ JNI 导出符号约 2144 个；不能使用同名空壳 .so。

2. 只有手机如何启动云端编译
前提：需要能通过手机浏览器使用 GitHub 账号，并允许使用 GitHub Actions。
A. 在 GitHub 建立一个新仓库（可以为 private），并打开仓库。
B. 用仓库页面的 Add file -> Create new file 创建文件：
   .github/workflows/build-imgui-arm64.yml
C. 将本包中的 FCL_ImGui_Android_1.86.12_云端编译.yml 全部内容粘贴进去并提交。
   注意 GitHub 网页可能需要在浏览器里开启“桌面网站”才能看到完整入口。
D. 打开仓库 Actions 标签页，找到 Build FCL ImGui 1.86.12 Android ARM64，
   点击 Run workflow 并运行。
E. 当任务成功时，到该次 Actions 运行页面最下面下载
   FCL-ImGui-1.86.12-Android-ARM64 产物 ZIP。
F. 解压后正常应包含：
   FCL-ImGui-Android-ARM64-1.86.12-addon.jar
   libimgui-java64.so
   BUILD-INFO.txt

3. 放入 FCL 测试
1) 备份整合包和 FCL JVM 参数。
2) 原来的 HueihueaEngine、HELoutreImGuiPart、FCL LWJGL Bridge 都保留。
3) 仅把 FCL-ImGui-Android-ARM64-1.86.12-addon.jar 放进
   /storage/emulated/0/Android/data/com.tungsten.fcl/files/.minecraft/mods/
   不要把 .so 单独放到 mods 文件夹，也不要将构建产物混入原 JAR。
4) JVM 参数里如果有以前试验性的 -Dimgui.library.path=...，
   先移除，允许 ImGui 使用原本的类路径原生资源加载机制。
5) 启动一次，查看是否出现 fclimguinative mod 注册以及 ImGui 的新错误。

4. 结果解释
- 完全没有之前的 'no imgui-java64 in java.library.path'，
  且 ImGui JNI 不再报错：说明原生库装载层有所进展，再测 UI。
- 出现 'dlopen failed'/'library is not accessible'：
  可能是 FCL/Android 的私有目录或 linker namespace 限制。
- 出现 'No implementation found for native ...'：
  JNI 导出名与 Java 类不匹配，或编译阶段遗漏文件。
- 出现 JNI crash / SIGSEGV：停止测试，移除 addon JAR。
- 编译任务失败：把 GitHub Actions 中的错误日志发给我；不要尝试用
  Windows DLL 或普通 Linux x86_64 .so 冒充 Android ARM64 库。
- 即使 ImGui 成功，MWProtect _ENY.zip 的 Linux 不支持问题依然独立存在。

5. 如何回退
从 FCL mods 移除新增的 FCL-ImGui-Android-ARM64-1.86.12-addon.jar，
即可恢复之前状态；两个原模组和 LWJGL Bridge 无需删除。

6. 构建工程的限制
- 未在 Android 设备上运行，不能承诺一键成功。
- GitHub Actions 的 Gradle JNI 生成、Android NDK 编译可能因上游依赖而报错。
- 若编译成功，仍须验证 FCL 1.3.4.0 / Java 8 / Forge 1.12.2 的实际 JNI、
  GL4ES/Krypton 绘制、JNI 回调、触屏输入及多类加载器兼容性。
- 构建从 imgui-java 官方 v1.86.12 tag 拉取源码，不上传你的任何原始 mod、
  受保护内容包、存档或服务器信息到 GitHub。

上游版本：https://github.com/SpaiR/imgui-java/tree/v1.86.12
Forge @Mod 文档：https://docs.minecraftforge.net/en/1.12.x/gettingstarted/structuring/
